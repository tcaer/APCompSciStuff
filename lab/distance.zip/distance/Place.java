public interface Place {

	int distance(Place other);

	int getX();

	int getY();

}